# PostgreSQL Database Setup Guide

## Prerequisites
The Spring Boot application requires PostgreSQL to be installed and running on your system.

## Installation Options

### Option 1: Install PostgreSQL Locally (Recommended)

1. **Download PostgreSQL**: 
   - Visit https://www.postgresql.org/download/windows/
   - Download the latest version for Windows

2. **Install PostgreSQL**:
   - Run the installer as administrator
   - Set a password for the `postgres` user (remember this password!)
   - Default port is 5432 (keep this)
   - Complete the installation

3. **Create Database**:
   ```sql
   -- Connect to PostgreSQL using pgAdmin or psql
   CREATE DATABASE loan_origination;
   ```

### Option 2: Using Docker (Alternative)

If you have Docker installed:

```bash
# Run PostgreSQL in Docker
docker run --name loan-origination-db -e POSTGRES_PASSWORD=password -e POSTGRES_DB=loan_origination -p 5432:5432 -d postgres:15

# To stop the container
docker stop loan-origination-db

# To start again
docker start loan-origination-db
```

## Application Configuration

The application is configured to connect to:
- **Host**: localhost
- **Port**: 5432
- **Database**: loan_origination
- **Username**: postgres
- **Password**: password

If you need to change these settings, edit `src/main/resources/application.properties`:

```properties
spring.datasource.url=jdbc:postgresql://localhost:5432/loan_origination
spring.datasource.username=postgres
spring.datasource.password=your_password_here
```

## Database Schema

The application uses JPA/Hibernate to automatically create tables on startup. The following tables will be created:

- users (customers and members)
- loan_applications
- personal_details
- employment_details
- nominee_details
- banking_details
- verification_details
- Various lookup tables (income_type, employment_type, etc.)

## Running the Application

Once PostgreSQL is running:

1. **Start the Spring Boot application**:
   ```bash
   mvn spring-boot:run
   ```

2. **Verify the application started**:
   - Look for log message: "Started LoanOriginationBackendApplication"
   - Application will run on: http://localhost:8080

## API Endpoints

### Authentication
- POST `/api/auth/register/customer` - Customer registration
- POST `/api/auth/register/member` - Member registration  
- POST `/api/auth/login` - Login (returns JWT token)

### Example Registration Request
```json
{
    "email": "customer@example.com",
    "password": "password123",
    "role": "CUSTOMER"
}
```

## Troubleshooting

### Connection Refused Error
If you see "Connection refused" errors:
1. Ensure PostgreSQL service is running
2. Check if port 5432 is available
3. Verify username/password in application.properties

### Database Not Found
If you see "database does not exist" errors:
1. Create the database: `CREATE DATABASE loan_origination;`
2. Restart the application

### Permission Denied
If you see permission errors:
1. Ensure the postgres user has proper permissions
2. Check if Windows firewall is blocking connections

## Next Steps

After successful startup:
1. Test authentication endpoints using Postman or curl
2. Create sample customer and member accounts
3. Test loan application submission
4. Verify file upload functionality
