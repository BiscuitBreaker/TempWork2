# Loan Origination Backend

A comprehensive Spring Boot backend system for a bank's loan origination process, implementing a maker-checker workflow with role-based access control.

## 🎯 Features

- **Multi-role Authentication**: Customer, Maker, and Checker roles with JWT-based authentication
- **Loan Application Workflow**: Complete loan processing from application to approval
- **Document Management**: File upload and storage for application documents
- **Maker-Checker Process**: Segregation of duties for loan processing
- **Audit Trail**: Complete history of application status changes
- **RESTful APIs**: Comprehensive REST endpoints for frontend integration
- **Database Schema**: Clean, normalized database design with proper relationships

## 🛠 Technology Stack

- **Framework**: Spring Boot 3.1.5
- **Security**: Spring Security with JWT
- **Database**: PostgreSQL 13+
- **ORM**: JPA/Hibernate
- **Build Tool**: Maven
- **Java Version**: 17+

## 📁 Project Structure

```
src/main/java/com/loanorigination/
├── entity/              # JPA entities matching database schema
├── repository/          # Data access layer
├── service/            # Business logic layer
├── controller/         # REST API controllers
├── dto/               # Data Transfer Objects
├── security/          # JWT and security configuration
├── config/            # Application configuration
└── exception/         # Custom exception handling
```

## 🗄️ Database Schema

The system implements a clean, normalized database schema with the following core entities:

### Core Tables
- **users** - Customer authentication and basic info
- **personal_details** - Customer personal information (1:1 with users)
- **employment_details** - Customer employment information (1:1 with users)
- **loan_applications** - Master loan application records
- **loan_details** - Loan business data and approval workflow
- **nominee_details** - Nominee information for applications

### Staff & Roles
- **members** - Bank employee authentication
- **roles** - Role definitions (CUSTOMER, MAKER, CHECKER, ADMIN)

### Document Management
- **user_documents** - Customer identity documents
- **loan_documents** - Application-related documents
- **document_types** - Document type definitions

### Workflow & Tracking
- **application_status_history** - Complete audit trail
- **internal_notes** - Staff communication and notes
- **loan_status_lookup** - Application status definitions

### Lookup Tables
- **gender_lookup**, **marital_status_lookup**, **occupation_lookup** - Reference data

## 🚀 Quick Start

### Prerequisites
- Java 17+
- Maven 3.6+
- PostgreSQL 13+

### Database Setup
1. Create PostgreSQL database:
```sql
CREATE DATABASE loan_origination;
```

2. Run the database initialization script:
```bash
psql -U postgres -d loan_origination -f database_init.sql
```

### Application Setup
1. Clone the repository
2. Update `application.properties` with your database credentials
3. Build the project:
```bash
mvn clean install
```

4. Run the application:
```bash
mvn spring-boot:run
```

The application will start on `http://localhost:8080`

## 📋 API Documentation

### Authentication Endpoints
- `POST /api/v1/auth/customer/register` - Customer registration
- `POST /api/v1/auth/customer/login` - Customer login  
- `POST /api/v1/auth/member/login` - Bank member login
- `GET /api/v1/auth/health` - Health check endpoint

### Customer APIs
- `GET /api/v1/customers/profile` - Get customer profile
- `PUT /api/v1/customers/personal-details` - Save personal details
- `PUT /api/v1/customers/employment-details` - Save employment details
- `POST /api/v1/customers/loan-applications` - Submit loan application
- `GET /api/v1/customers/loan-applications` - Get customer's applications

### Maker APIs  
- `GET /api/v1/makers/applications/pending` - Get pending applications
- `PUT /api/v1/makers/applications/{id}/approve` - Approve application
- `PUT /api/v1/makers/applications/{id}/reject` - Reject application
- `POST /api/v1/makers/applications/{id}/notes` - Add internal notes

### Checker APIs
- `GET /api/v1/checkers/applications/pending` - Get applications for final approval
- `PUT /api/v1/checkers/applications/{id}/approve` - Final approval
- `PUT /api/v1/checkers/applications/{id}/reject` - Final rejection

### Document Management
- `POST /api/v1/documents/upload` - Upload documents
- `GET /api/v1/documents/{id}` - Download document
- `GET /api/v1/documents/types` - Get document types

## ⚙️ Configuration

### Database Configuration
Update `application.properties`:

```properties
spring.datasource.url=jdbc:postgresql://localhost:5432/loan_origination
spring.datasource.username=postgres
spring.datasource.password=your_password
spring.jpa.hibernate.ddl-auto=validate
spring.jpa.show-sql=false
```

### JWT Configuration
```properties
jwt.secret=your_jwt_secret_key_here
jwt.expiration=86400000
```

### File Upload Configuration
```properties
spring.servlet.multipart.max-file-size=10MB
spring.servlet.multipart.max-request-size=10MB
file.upload.dir=uploads/
```

## 🔧 Development

### Running Tests
```bash
mvn test
```

### Code Coverage
```bash
mvn jacoco:report
```

### API Documentation
- **Swagger UI**: `http://localhost:8080/swagger-ui/index.html`
- **OpenAPI JSON**: `http://localhost:8080/v3/api-docs`

## 📊 Database Schema

The database schema is defined in `database_schema.dbml` and implemented in `database_init.sql`. Key features:

- **Clean Separation**: Clear separation between authentication, customer data, and loan processing
- **Audit Trail**: Complete tracking of application status changes
- **Referential Integrity**: Proper foreign key relationships
- **Performance**: Strategic indexing for optimal query performance
- **Seed Data**: Pre-populated lookup tables and sample users

## 🔒 Security

- **JWT Authentication**: Stateless authentication with role-based access
- **Password Encryption**: BCrypt hashing for all passwords
- **CORS Configuration**: Configured for frontend integration
- **Input Validation**: Comprehensive validation on all endpoints
- **File Upload Security**: Safe file handling and storage

## 🚦 Status

**Current Status**: ✅ **Production Ready**

- ✅ Complete database schema implemented
- ✅ All entities and repositories configured
- ✅ JWT security fully implemented
- ✅ REST APIs defined and functional
- ✅ Database connection and initialization complete
- ✅ Application starts successfully on port 8080

## 📝 Notes

- Application uses PostgreSQL as the primary database
- JWT tokens expire after 24 hours (configurable)
- File uploads are stored locally (can be configured for cloud storage)
- All endpoints support JSON request/response format
- Comprehensive error handling with meaningful error messages

## Security

- JWT-based authentication with configurable expiration
- Role-based access control (RBAC)
- CORS configuration for frontend integration
- Password encryption using BCrypt

## Development Guidelines

1. **Entity Design**: All entities follow JPA best practices with proper relationships
2. **Service Layer**: Business logic is separated from controllers
3. **Error Handling**: Comprehensive error handling with custom exceptions
4. **Validation**: Input validation using Bean Validation
5. **Testing**: Unit tests for service and repository layers

## Integration with Frontend

This backend is designed to work with the React frontend located in the `loan_origination` folder. The APIs provide all necessary endpoints for:

- User authentication and registration
- Multi-step application forms
- Document upload and management
- Dashboard data for different user roles
- Application status tracking

## Future Enhancements

- Email notifications for status changes
- Advanced reporting and analytics
- Integration with external credit scoring systems
- Mobile API support
- Advanced audit logging
